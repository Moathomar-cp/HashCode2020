const fs = require("fs");
const fileNames = [
  "a_example.txt",
  "b_read_on.txt",
  "f_libraries_of_the_world.txt"
].map(f => __dirname + "/" + f);

// fileNames
const fileName = fileNames[0];
const lines = fs.readFileSync(fileName, "utf-8").split("\n");
const [booksCount, librariesCount, scaningDays] = lines
  .shift()
  .split(" ")
  .map(Number);
const scoreOfBooks = lines
  .shift()
  .split(" ")
  .map(Number);

const libConfigs = {};

Array.of({ length: librariesCount }).forEach((_, libIndex) => {
  const [libBooksCounts, libDaysToSign, libBooksPerDay] = lines
    .shift()
    .split(" ")
    .map(Number);

  const libBookIds = lines
    .shift()
    .split(" ")
    .map(Number);

  libConfigs[libIndex] = {
    libBooksCounts,
    libDaysToSign,
    libBooksPerDay,
    libBookIds
  };
});

const answer = `2 
1 3 
5 2 3 
0 5 
0 1 2 3 4 
 `;

fs.writeFileSync(fileName.replace("txt","out"), answer, "utf-8");
